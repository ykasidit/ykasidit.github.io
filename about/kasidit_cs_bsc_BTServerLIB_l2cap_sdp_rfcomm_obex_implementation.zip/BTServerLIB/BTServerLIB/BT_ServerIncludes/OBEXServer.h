#pragma once

class OBEXServer
	{
	public:
		OBEXServer(void);
		~OBEXServer(void);
	};
