#pragma once
#include "afxcoll.h"

class TidyVector :
	public CPtrArray
	{
	public:
		TidyVector(void);
		void RemoveAt( int nIndex);
		void RemoveAll( );
		~TidyVector(void);
	};
