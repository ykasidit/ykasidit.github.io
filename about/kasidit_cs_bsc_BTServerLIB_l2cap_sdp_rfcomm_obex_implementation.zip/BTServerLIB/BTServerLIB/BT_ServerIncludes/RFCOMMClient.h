#pragma once

class RFCOMMClient
	{
	public:
		RFCOMMClient(void);
		~RFCOMMClient(void);
	};
