#include "stdafx.h"
#include "tidyvector.h"

TidyVector::TidyVector(void)
	{
	}

void TidyVector::RemoveAt( int nIndex )
	{
		delete (this->GetAt(nIndex));		 
		CPtrArray::RemoveAt(nIndex,1);

	}
void TidyVector::RemoveAll( )
	{
		for(int i=0;i<this->GetSize();i++)
			delete (this->GetAt(i));		 
		CPtrArray::RemoveAll();
	}
TidyVector::~TidyVector(void)
	{
		this->RemoveAll();
	}