#pragma once
#include "afxcoll.h"

class HCIClientVector :	public CPtrArray
	{
	public:
		HCIClientVector(void);
		void RemoveAt( int nIndex);
		void RemoveAll( );
		~HCIClientVector(void);
	};
