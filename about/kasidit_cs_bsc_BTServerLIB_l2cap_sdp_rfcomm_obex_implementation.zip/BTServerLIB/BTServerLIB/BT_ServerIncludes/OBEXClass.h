#pragma once

class OBEXClass
	{
	public:
		OBEXClass(void);
		~OBEXClass(void);
	};
