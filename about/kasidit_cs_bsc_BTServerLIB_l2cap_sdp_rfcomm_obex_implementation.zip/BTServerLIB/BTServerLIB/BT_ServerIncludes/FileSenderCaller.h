#pragma once
#include "HCIClientCaller.h"
class FileSenderCaller : HCIClientCaller
	{
	public:
		FileSenderCaller(void);		
		virtual void OnSendSessionComplete(CStdioFile* file, bool success);		
		void OnInquiryComplete();
		void OnGetNamesComplete();
		virtual ~FileSenderCaller(void);
	};
