#pragma once

class SDPServer
	{
	public:
		SDPServer(void);
		~SDPServer(void);
	};
