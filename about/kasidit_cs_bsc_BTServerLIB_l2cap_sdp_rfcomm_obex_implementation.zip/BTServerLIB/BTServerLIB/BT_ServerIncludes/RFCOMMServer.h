#pragma once

class RFCOMMServer
	{
	public:
		RFCOMMServer(void);
		~RFCOMMServer(void);
	};
