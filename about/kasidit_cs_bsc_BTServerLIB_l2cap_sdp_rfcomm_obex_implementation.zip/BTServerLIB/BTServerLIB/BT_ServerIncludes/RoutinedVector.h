#pragma once
#include "TidyVector.h"

class RoutinedVector : public TidyVector
	{
	public:
		RoutinedVector(void* server);
		int Add(void* newElement);
		void OnEventPktComplete();
		~RoutinedVector(void);
	
	protected:		
		//bool Sending;
		void* Server;
	};
