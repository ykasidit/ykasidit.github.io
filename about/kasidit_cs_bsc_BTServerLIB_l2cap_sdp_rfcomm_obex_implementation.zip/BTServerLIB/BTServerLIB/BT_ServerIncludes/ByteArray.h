#ifndef BYTEARRAY_H
#define BYTEARRAY_H

#ifndef USHORT 
#define USHORT unsigned short
#endif

#ifndef UWORD
#define UWORD unsigned int
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

class ByteArray
{
	public:
	BYTE* array;
	int length;
	ByteArray(BYTE* array,int length);
	ByteArray(){};
};

class ByteArrayAlloc : public ByteArray
{
	
	public:
	ByteArrayAlloc(BYTE* array,int length); //allocate new sapce and copy from src
	ByteArrayAlloc(int length);	
	~ByteArrayAlloc(); // free the space allocated by the constructor
};



#endif
