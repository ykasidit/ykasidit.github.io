#pragma once

class SDPClient
	{
	public:
		SDPClient(void);
		~SDPClient(void);
	};
