#pragma once

class OBEXClient
	{
	public:
		OBEXClient(void);
		~OBEXClient(void);
	};
