#pragma once

class HCIClientCaller
	{
	public:
		HCIClientCaller(void);
		virtual void OnInquiryComplete();		
		virtual void OnGetNamesComplete();
		virtual void OnDisconnect(USHORT handle);
		virtual void OnInput(USHORT handle,BYTE* payLoad, USHORT length);
		~HCIClientCaller(void);
	};
