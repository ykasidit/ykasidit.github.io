#pragma once



class L2CAPClientCaller 
	{
	   public:

		L2CAPClientCaller(void);
		void OnL2CAPDisconnected(USHORT PSM, USHORT CID, DWORD l2client, bool HCIDiscToo);
		void OnL2CAPDataInput(DWORD l2client, BYTE* payLoad, USHORT length);
		void OnL2CAPConnectedAndConfigured(USHORT PSM, USHORT CID, DWORD l2client,bool success);
		~L2CAPClientCaller(void);
	};
