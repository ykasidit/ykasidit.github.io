#include "stdafx.h"
#include ".\obexserver.h"

OBEXServer::OBEXServer(void)
	{
	}

OBEXServer::~OBEXServer(void)
	{
	}
