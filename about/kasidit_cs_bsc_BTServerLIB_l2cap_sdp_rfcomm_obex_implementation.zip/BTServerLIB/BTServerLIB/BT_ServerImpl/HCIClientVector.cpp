#include "stdafx.h"
#include ".\hciclientvector.h"

HCIClientVector::HCIClientVector(void)
	{

	}
void HCIClientVector::RemoveAt( int nIndex )
	{
		delete (this->GetAt(nIndex));		 
		CPtrArray::RemoveAt(nIndex,1);

	}
void HCIClientVector::RemoveAll( )
	{
		for(int i=0;i<this->GetSize();i++)
			delete (this->GetAt(i));		 
		CPtrArray::RemoveAll();
	}
HCIClientVector::~HCIClientVector(void)
	{
		this->RemoveAll();
	}
