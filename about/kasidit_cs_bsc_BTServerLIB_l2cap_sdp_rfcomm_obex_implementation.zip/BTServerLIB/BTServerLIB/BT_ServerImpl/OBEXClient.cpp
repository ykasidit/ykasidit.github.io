#include "stdafx.h"
#include ".\obexclient.h"

OBEXClient::OBEXClient(void)
	{
	}

OBEXClient::~OBEXClient(void)
	{
	}
