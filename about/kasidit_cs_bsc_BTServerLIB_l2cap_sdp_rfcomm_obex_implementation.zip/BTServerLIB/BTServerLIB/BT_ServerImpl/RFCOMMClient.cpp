#include "stdafx.h"
#include ".\rfcommclient.h"

RFCOMMClient::RFCOMMClient(void)
	{
	}

RFCOMMClient::~RFCOMMClient(void)
	{
	}
