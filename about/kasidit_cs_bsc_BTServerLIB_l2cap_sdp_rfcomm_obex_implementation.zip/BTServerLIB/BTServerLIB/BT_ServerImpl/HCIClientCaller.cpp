#include "StdAfx.h"
#include ".\hciclientcaller.h"

HCIClientCaller::HCIClientCaller(void)
	{
	}
void HCIClientCaller::OnInput(USHORT handle,BYTE* payLoad, USHORT length){};
void HCIClientCaller::OnGetNamesComplete(){}
void HCIClientCaller::OnInquiryComplete(){}
void HCIClientCaller::OnDisconnect(USHORT handle){}
HCIClientCaller::~HCIClientCaller(void)
	{
	}
