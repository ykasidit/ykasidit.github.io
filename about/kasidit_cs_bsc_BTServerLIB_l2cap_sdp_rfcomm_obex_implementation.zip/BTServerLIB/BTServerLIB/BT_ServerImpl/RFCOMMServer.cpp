#include "stdafx.h"
#include ".\rfcommserver.h"

RFCOMMServer::RFCOMMServer(void)
	{
	}

RFCOMMServer::~RFCOMMServer(void)
	{
	}
