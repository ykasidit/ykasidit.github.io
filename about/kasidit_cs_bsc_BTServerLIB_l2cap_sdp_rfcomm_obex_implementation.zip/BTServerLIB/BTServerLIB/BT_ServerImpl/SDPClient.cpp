#include "stdafx.h"
#include ".\sdpclient.h"

SDPClient::SDPClient(void)
	{
	}

SDPClient::~SDPClient(void)
	{
	}
