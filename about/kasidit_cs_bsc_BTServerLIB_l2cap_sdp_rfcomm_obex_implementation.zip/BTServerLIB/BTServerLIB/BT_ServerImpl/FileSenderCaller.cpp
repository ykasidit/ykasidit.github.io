#include "StdAfx.h"
#include ".\filesendercaller.h"

FileSenderCaller::FileSenderCaller(void)
	{
	

	}
void FileSenderCaller::OnInquiryComplete()
	{
	
	
	}
void FileSenderCaller::OnSendSessionComplete(CStdioFile* file, bool success)
	{
	

	}
void FileSenderCaller::OnGetNamesComplete()
	{
	
	
	}

FileSenderCaller::~FileSenderCaller(void)
	{
	
	
	}
