#include "stdafx.h"
#include "ByteArray.h"

ByteArray::ByteArray(BYTE* array,int length){this->array = array; this->length = length;};

ByteArrayAlloc::ByteArrayAlloc(int length){this->length = length; this->array = new BYTE[length];};
ByteArrayAlloc::ByteArrayAlloc(BYTE* array,int length) //allocate new sapce and copy from src
{
		int i;

		this->array = new BYTE[length];
		this->length=length;
		for(i=length -1; i>=0; i--)
			*(this->array+i) = *(array+i);	
		
};
ByteArrayAlloc::~ByteArrayAlloc(){delete[] array;};
