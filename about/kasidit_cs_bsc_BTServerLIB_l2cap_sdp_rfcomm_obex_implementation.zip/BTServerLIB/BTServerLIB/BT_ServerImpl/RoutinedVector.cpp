#include "StdAfx.h"
#include "HCIServer.h"
#include ".\routinedvector.h"

RoutinedVector::RoutinedVector(void* server)
	{                                           
		this->Server = server;
	}
int RoutinedVector::Add(void *p)
	{
		
		int ret = TidyVector::Add(p);	
		
		if(this->GetSize()==1)			
			{
			PFBT_HCI_DATA_PACKET pData =(PFBT_HCI_DATA_PACKET)p;
		DWORD   dwBytesWritten =0;
			if (((HCIServer*)Server)->SendData((void*)pData,pData->DataLength+4, &dwBytesWritten, NULL)==ERROR_SUCCESS)
				{
						char szBuffer[1024]={0};
						char szBufferShort[20]={0};

						sprintf(szBuffer, "W: ");
						for (DWORD k=0; k<dwBytesWritten; k++)
						{
							sprintf(szBufferShort, "%02x ", ((PBYTE)pData)[k]);
							strcat(szBuffer, szBufferShort);
						}
						((HCIServer*)Server)->LogLB->AddString(szBuffer);
				
						//fbtLog(fbtLog_Verbose, "CBTTestDlg::SendData: written %d bytes: %s", dwBytesWritten,szBuffer );            
				}
				else
					{((HCIServer*)Server)->LogLB->AddString("HCI RoutineVector Send failed");}
				//this->RemoveAt(0);
			}
		
		return ret;

	}
void RoutinedVector::OnEventPktComplete()
	{
		int nnow = this->GetSize();	
		  if(nnow>0)			
			{
			this->RemoveAt(0);
			if(nnow==1)
				return;
			PFBT_HCI_DATA_PACKET pData =(PFBT_HCI_DATA_PACKET)this->GetAt(0);//next packet
		DWORD   dwBytesWritten =0;
			if (((HCIServer*)Server)->SendData((void*)pData,pData->DataLength+4, &dwBytesWritten, NULL)==ERROR_SUCCESS)
				{
						char szBuffer[1024]={0};
						char szBufferShort[20]={0};

						sprintf(szBuffer, "W: ");
						for (DWORD k=0; k<dwBytesWritten; k++)
						{
							sprintf(szBufferShort, "%02x ", ((PBYTE)pData)[k]);
							strcat(szBuffer, szBufferShort);
						}
						((HCIServer*)Server)->LogLB->AddString(szBuffer);
				
						//fbtLog(fbtLog_Verbose, "CBTTestDlg::SendData: written %d bytes: %s", dwBytesWritten,szBuffer );            
				}
				else
					{((HCIServer*)Server)->LogLB->AddString("HCI RoutineVector OnSend failed");}
				//this->RemoveAt(0);
			}
	
	}

RoutinedVector::~RoutinedVector(void)
	{
	
	}
