#include "StdAfx.h"
#include ".\l2capclientcaller.h"

L2CAPClientCaller::L2CAPClientCaller(void)
	{

	}

L2CAPClientCaller::~L2CAPClientCaller(void)
	{

	}
void L2CAPClientCaller::OnL2CAPDisconnected(USHORT PSM, USHORT CID, DWORD l2client, bool HCIDiscToo)
	{
	
	
	}
void L2CAPClientCaller::OnL2CAPDataInput(DWORD l2client, BYTE* payLoad, USHORT length)
	{
	
	
	}
void L2CAPClientCaller::OnL2CAPConnectedAndConfigured(USHORT PSM, USHORT CID, DWORD l2client,bool success)
	{
	
	
	}