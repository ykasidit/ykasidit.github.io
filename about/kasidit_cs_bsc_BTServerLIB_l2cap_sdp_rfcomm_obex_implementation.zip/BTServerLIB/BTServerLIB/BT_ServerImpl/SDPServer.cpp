#include "stdafx.h"
#include ".\sdpserver.h"

SDPServer::SDPServer(void)
	{
	}

SDPServer::~SDPServer(void)
	{
	}
