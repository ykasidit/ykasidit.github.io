#include "stdafx.h"
#include ".\obexclass.h"

OBEXClass::OBEXClass(void)
	{
	}

OBEXClass::~OBEXClass(void)
	{
	}
